#!/bin/bash

if [ $# -eq 5 ];then
  if [[ $4 == "aliyun" ]];then
    ansible-playbook ABE.yml -e "update_filename=$2" -e "project_name=$1" --tags=$4
    sed -ri "s/(- hosts: )(.*)/\1${3}/"  Project_Update.yml && ansible-playbook Project_Update.yml -vvv -e "update_filename=$2" -e "project_name=$1" --tags=$4
    echo "restart all server"
    sed -ri "s/(- hosts: )(.*)/\1${3}/"  Start_Stop.yml && ansible-playbook Start_Stop.yml -e "project_name=$1" --tags=$5
    wait
  elif [[ $4 == "bjidc" ]];then
    sed -ri "s/(- hosts: )(.*)/\1${3}/"  Project_Update.yml && ansible-playbook Project_Update.yml -vvv -e "update_filename=$2" -e "project_name=$1" --tags=$4
    echo "restart all server"
    sed -ri "s/(- hosts: )(.*)/\1${3}/"  Start_Stop.yml && ansible-playbook Start_Stop.yml -e "project_name=$1" --tags=$5
    wait
  else
    echo "error args"
  fi
elif [ $# -eq 6 ];then
  if [[ $4 == "aliyun" ]];then
    ansible-playbook ABE.yml -e "update_filename=$2" -e "project_name=$1" --tags=$4
    sed -ri "s/(- hosts: )(.*)/\1${3}/"  Project_Update.yml && ansible-playbook Project_Update.yml -vvv -e "update_filename=$2" -e "project_name=$1" --tags=$4
    echo "restart single $6"
    sed -ri "s/(- hosts: )(.*)/\1${3}/"  Start_Stop.yml && ansible-playbook Start_Stop.yml -e "project_name=$1" -e "server_name=$6" --tags=$5
    wait
  elif [[ $4 == "bjidc" ]];then
    sed -ri "s/(- hosts: )(.*)/\1${3}/"  Project_Update.yml && ansible-playbook Project_Update.yml -vvv -e "update_filename=$2" -e "project_name=$1" --tags=$4
    echo "restart single $6"
    sed -ri "s/(- hosts: )(.*)/\1${3}/"  Start_Stop.yml && ansible-playbook Start_Stop.yml -e "project_name=$1" -e "server_name=$6" --tags=$5
    wait
  else
    echo "error args"
  fi
else
  echo "Usage: $0 <project_name> <update_filename> <update_hostip> <bjidc|aliyun> <allserver|singleserver servername> "
fi
